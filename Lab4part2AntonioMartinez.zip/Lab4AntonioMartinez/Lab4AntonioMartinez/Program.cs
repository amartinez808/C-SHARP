﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Lab4AntonioMartinez
{
    public class BasicTools
    {
        public static void Pause()
        {
            Console.WriteLine("\nPress Any Key to Continue\n");
            Console.ReadLine();
        }



    }
    class Program
    {

        struct Person
        {
            public string FirstName;
            public string MiddleName;
            public string LastName;
            public string Street1;
            public string Street2;
            public string City;
            public string State;
            public string Email;
            public int Zip;
            public double Phone;
            
        }
        static void Main(string[] args)
        {
            bool blnResult = false;

            Person tempPerson = new Person();

            Console.WriteLine("\nPLease enter first name: ");
            tempPerson.FirstName = Console.ReadLine() + "\tPoopy Johnson";

            Console.WriteLine("\nPLease enter middle name: ");
            tempPerson.MiddleName = Console.ReadLine();

            Console.WriteLine("\nPLease enter Last name ");
            tempPerson.LastName = Console.ReadLine();

            Console.WriteLine("\nPLease enter Street adreess 1: ");
            tempPerson.Street1 = Console.ReadLine();

            Console.WriteLine("\nPLease enter Street adreess 2: ");
            tempPerson.Street2 = Console.ReadLine();

            Console.WriteLine("\nPLease enter City: ");
            tempPerson.City = Console.ReadLine();

            Console.WriteLine("\nPLease enter State: ");
            tempPerson.State = Console.ReadLine();

            Console.WriteLine("\nPLease enter Email: ");
            tempPerson.Email = Console.ReadLine();

            

            do
            {
                Console.WriteLine("\nPlease enter the Zip: ");
                blnResult = Int32.TryParse(Console.ReadLine(), out tempPerson.Zip);

                if (blnResult == false)
                {
                    Console.Write("\nSorry Incorrect Zip code format. Please Try again.         (Ex: 02863) ");
                }

            } while (blnResult == false);

            do
            {
                Console.Write("\nPlease enter the phone #: ");
                blnResult = Double.TryParse(Console.ReadLine(), out tempPerson.Phone);

                if (blnResult == false)
                {
                    Console.Write("\nSorry incorrect phone #. Please try again.  ( Ex: 2143457567 ) ");
                }

            } while (blnResult == false);

           



            Console.Write("\n\nWe now have the following Person: ");
            Console.Write($"\n Person' Name is: {tempPerson.FirstName}\t{tempPerson.MiddleName}\t{tempPerson.LastName}");
            Console.Write($"\n Address 1 & 2: {tempPerson.Street1} \n{tempPerson.Street2}");
            Console.Write($"\n E-Mail: {tempPerson.Email}");
            Console.Write($"\n City: {tempPerson.City}");
            Console.Write($"\n State: {tempPerson.State}");
            Console.Write($"\n Zip Code: ${tempPerson.Zip}");


            BasicTools.Pause();

            

        }
    }
}

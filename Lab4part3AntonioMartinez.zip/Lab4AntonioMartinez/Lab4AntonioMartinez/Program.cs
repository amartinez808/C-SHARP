﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Lab4AntonioMartinez
{
    public class BasicTools
    {
        public static void Pause()
        {
            Console.WriteLine("\nPress Any Key to Continue\n");
            Console.ReadLine();
        }



    }
    class Program
    {

        public class Person
        {
            private string FirstName;
            private string MiddleName;
            private string LastName;
            private string Street1;
            private string Street2;
            private string City;
            private string State;
            private string Email;
            private double Zip;
            private double Phone;



            public string FName
            {
                get
                {
                    return FirstName;
                }

                set
                {
                    FirstName = value;
                }
            }


            public string MName
            {
                get
                {
                    return MiddleName;
                }

                set
                {
                    MiddleName = value;
                }
            }


            public string LName
            {
                get
                {
                    return LastName;
                }

                set
                {
                    LastName = value;
                }
            }


            public string St1
            {
                get
                {
                    return Street1;
                }

                set
                {
                    Street1 = value;
                }
            }


            public string St2
            {
                get
                {
                    return Street2;
                }

                set
                {
                    Street2 = value;
                }
            }

            public string CITY
            {
                get
                {
                    return City;
                }

                set
                {
                    City = value;
                }
            }

            public string STATE
            {
                get
                {
                    return State;
                }

                set
                {
                    State = value;
                }
            }

            public string EMAIL
            {
                get
                {
                    return Email;
                }

                set
                {
                    Email = value;
                }
            }

            public double ZIP
            {
                get
                {
                    return Zip;
                }

                set
                {

                    Zip = value;

                }
            }

            public double PHONE
            {
                get
                {
                    return Phone;
                }

                set
                {

                    Phone = value;

                }





            }














            static void Main(string[] args)
            {
                bool blnResult = false;

                Person tempPerson = new Person();

                Console.WriteLine("\nPLease enter first name: ");
                tempPerson.FName = Console.ReadLine() + "\tPoopy Johnson";

                Console.WriteLine("\nPLease enter middle name: ");
                tempPerson.MName = Console.ReadLine();

                Console.WriteLine("\nPLease enter Last name ");
                tempPerson.LName = Console.ReadLine();

                Console.WriteLine("\nPLease enter Street adreess 1: ");
                tempPerson.St1 = Console.ReadLine();

                Console.WriteLine("\nPLease enter Street adreess 2: ");
                tempPerson.St2 = Console.ReadLine();

                Console.WriteLine("\nPLease enter City: ");
                tempPerson.CITY = Console.ReadLine();

                Console.WriteLine("\nPLease enter State: ");
                tempPerson.STATE = Console.ReadLine();

                Console.WriteLine("\nPLease enter Email: ");
                tempPerson.EMAIL = Console.ReadLine();



                do
                {
                    Console.WriteLine("\nPlease enter the Zip: ");
                    double dblTempZip;
                    blnResult = Double.TryParse(Console.ReadLine(), out dblTempZip);

                    if (blnResult == false)
                    {
                        Console.Write("\nSorry Incorrect Zip code format. Please Try again.         (Ex: 02863) ");
                    }
                    else
                    {
                        tempPerson.ZIP = dblTempZip;
                    }

                } while (blnResult == false);




                do
                {
                    Console.Write("\nPlease enter the phone #: ");
                    double dblTempPhone;
                    blnResult = Double.TryParse(Console.ReadLine(), out dblTempPhone);

                    if (blnResult == false)
                    {
                        Console.Write("\nSorry incorrect phone #. Please try again.  ( Ex: 2143457567 ) ");
                    }
                    else
                    {
                        tempPerson.PHONE = dblTempPhone;
                    }

                } while (blnResult == false);





                Console.Write("\n\nWe now have the following Person: ");
                Console.Write($"\n Person' Name is: {tempPerson.FirstName}\t{tempPerson.MiddleName}\t{tempPerson.LastName}");
                Console.Write($"\n Address 1 & 2: {tempPerson.Street1} \n{tempPerson.Street2}");
                Console.Write($"\n E-Mail: {tempPerson.Email}");
                Console.Write($"\n City: {tempPerson.City}");
                Console.Write($"\n State: {tempPerson.State}");
                Console.Write($"\n Zip Code: {tempPerson.Zip}");


                BasicTools.Pause();

            }


        }

    }
}